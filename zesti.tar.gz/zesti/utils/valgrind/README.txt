A few valgrind suppression files for known leaks. The LLVM ones may be
fixed by now.
